"""Inventory management application"""
