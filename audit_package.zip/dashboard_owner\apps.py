from django.apps import AppConfig


class DashboardOwnerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dashboard_owner'
